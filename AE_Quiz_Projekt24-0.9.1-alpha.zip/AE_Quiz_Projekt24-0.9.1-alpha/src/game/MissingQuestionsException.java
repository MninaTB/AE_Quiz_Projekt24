package game;

/**
 * Erstellung einer Exception, weil keine passende zur Verfuegung stand.
 */
public class MissingQuestionsException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
