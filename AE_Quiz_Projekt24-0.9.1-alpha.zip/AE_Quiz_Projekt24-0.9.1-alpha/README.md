# AE_Quiz_Projekt24

## UML

![uml diagram](doc/assets/project_uml_diagram.png "uml diagram")
